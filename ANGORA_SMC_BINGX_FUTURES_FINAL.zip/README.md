# ANGORA SMC PRO — BingX Futures

Bu paket yalnızca **BingX USDT-M Perpetual Futures** piyasası için hazırlanmıştır.

## İçerik
- `index.html` — ana arayüz
- `style.css` — mobil uyumlu arayüz
- `app.js` — BingX Futures REST + WebSocket ve SMC tarama
- `README.md` — kullanım

## Piyasa kapsamı
- BTC-USDT
- BingX'teki uygun USDT perpetual altcoin sözleşmeleri
- Spot kullanılmaz.
- Forex, endeks, metal ve hisse taranmaz.
- UP/DOWN/BULL/BEAR leveraged token sembolleri filtrelenir.

## Çalıştırma
Dosyaları aynı klasörde tutup `index.html` dosyasını bir statik hosting'e yükleyin.
GitHub Pages, Cloudflare Pages veya benzeri statik hosting kullanılabilir.

## Veri
Public BingX Futures market endpoints kullanılır; kullanıcı API anahtarı gerektirmez.
Tarayıcı ortamında CORS veya BingX API değişikliği olursa ilgili endpointlerin güncellenmesi gerekebilir.

## SMC
Tarama; market structure/BOS, liquidity sweep, displacement, FVG, order block, premium/discount ve EMA bias bileşenlerinden bir confluence skoru oluşturur.
Bu teknik bir tarama aracıdır; yatırım tavsiyesi değildir.
